# Time estimates for instructors

* n = 8
* median = 2.25 hours

# Resources

*   `img`: images used in lessons
