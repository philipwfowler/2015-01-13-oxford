These folders contain three different types of files:

1. the files required to follow along during the Software Carpentry course. For example, the shell/ folder contains the filesystem/ folder that we use during our look at the Unix shell and the sql/ folder contains the database we use in that part of the course (survey.db).

2. markdown files that have the same content as the GitHub website. These will be harder to read, but they are there.

3. in the python/ folder the ipythonnotebook files are also included. These mirror the separate sections of the python section of the workshop. How to use these will be demonstrated during the workshop. In brief, you need to have ipython in addition to python installed. Then start a notebook server via

 ipython notebook

This will open a window in our default web browser from where you can open each notebook in turn. Each python statement can be executed by pressing Shift+Enter.

For more information, please see the workshop GitHib site at

http://philipwfowler.github.io/2015-01-13-oxford/

Philip Fowler, 7 Jan 15

